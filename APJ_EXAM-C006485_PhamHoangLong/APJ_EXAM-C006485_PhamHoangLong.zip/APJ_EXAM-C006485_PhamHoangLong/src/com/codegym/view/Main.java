package com.codegym.view;

public class Main {
    public static void main(String[] args) {
        MobilePhoneFunction mobilePhoneFunction = new MobilePhoneFunction();
        mobilePhoneFunction.displayMenu();
    }
}
